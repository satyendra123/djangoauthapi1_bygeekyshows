## Resume Uploader Django Project
### Watch Tutorial:- https://youtu.be/835Ez8SeAvE


### Highlights:
* Radio Button
* Multiple Checkbox
* Image File
* Doc/PDF File
* Select Field
* Date Picker
* Delete Unused Media File

### Connect React JS with Django
#### Video Tutorial https://youtu.be/tiungJDoQyA

### To run this Project follow below steps
```bash
npm install
npm start
```

## Django REST Framework Complete Session Authentication API
### Video Link:- https://youtu.be/jh89xLUsD4U

## To Run this Project follow below:

```bash
mkvirtualenv venv
venv\scripts\activate
pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py runserver
```

#### There is a File "sessionauth.postman_collection" which has Postman Collection You can import this file in your postman to test this API


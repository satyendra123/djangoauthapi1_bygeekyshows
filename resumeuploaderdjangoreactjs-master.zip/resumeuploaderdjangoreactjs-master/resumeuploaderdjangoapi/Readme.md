## Resume Uploader Django API DRF
### Video Link:- https://youtu.be/FDdK9VQFHzY

## To Run this Project follow below:

```bash
mkvirtualenv resumeup
pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py runserver
```

#### There is a File "ResumeUploaderAPI.postman_collection" which has Postman Collection You can import this file in your postman to test this API



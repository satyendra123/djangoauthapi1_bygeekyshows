## React JS Complete Authentication and Dashboard UI
### https://youtu.be/SzjeoauKvig

## To Run this Project via NPM follow below:

```bash
npm install
npm start
```

